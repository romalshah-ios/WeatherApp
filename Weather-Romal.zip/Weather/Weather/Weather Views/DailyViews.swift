//  DailyViews.swift

import SwiftUI

struct DailyWeatherView: View {
    @StateObject var weatherViewModel: WeatherViewModel
    
    var body: some View {
        ForEach(weatherViewModel.weather.daily) { weather in
            LazyVStack {
                DailyWeatherCell(weather: weather)
            }
        }
    }
    
    private func DailyWeatherCell(weather: WeatherDaily) -> some View {
        HStack {
            HStack {
                Text(weatherViewModel.getDayFor(weather.date).uppercased())
                    .frame(width: 50)
                Text(weatherViewModel.getDayNumber(weather.date))
            }
            Spacer()
            weatherViewModel.getWeatherIconFor(icon: weather.weather[0].icon)
                .resizable()
                .scaledToFill()
                .frame(width: Constants.Dimensions.defaultWidth,
                       height: Constants.Dimensions.defaultHeight,
                       alignment: .center)
            Spacer()
            HStack {
                Image(Constants.Images.cold)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 20)
                Text("\(weatherViewModel.getTempFor(weather.temperature.min))°C")
            }
            Spacer()
            HStack {
                Image(Constants.Images.warm)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 20)
                Text("\(weatherViewModel.getTempFor(weather.temperature.max))°C")
            }
        }
        .font(.system(size: Constants.Font.smallSize))
        .foregroundStyle(.white)
        .padding(.horizontal, 10)
        .padding(.vertical, 15)
        .background(
            RoundedRectangle(cornerRadius: Constants.Dimensions.cornerRadius)
                .fill(
                    LinearGradient(
                        gradient: Gradient(colors: Constants.Colors.gradient),
                        startPoint: .topLeading, endPoint: .bottomTrailing
                    )
                )
        )
        .shadow(color: Color.white.opacity(0.1),
                radius: 2,
                x: -2,
                y: -2)
        .shadow(color: Color.black.opacity(0.2),
                radius: 2,
                x: 2,
                y: 2)
    }
}

struct DailyWeatherView_Previews: PreviewProvider {
    static var previews: some View {
        DailyWeatherView(weatherViewModel: WeatherViewModel())
    }
}

struct HourlyView: View {
    @StateObject var weatherViewModel: WeatherViewModel
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: Constants.Dimensions.secondSpacing) {
                ForEach(weatherViewModel.weather.hourly) { weather in
                    let icon = weatherViewModel.getWeatherIconFor(icon: (weather.weather.count > 0) ? weather.weather[0].icon : "sun")
                    let hour = weatherViewModel.getTimeFor(weather.date)
                    let temp = weatherViewModel.getTempFor(weather.temperature)
                    
                    HourlyWeatherCell(hour: hour, image: icon, temp: temp)
                }
            }
        }
    }
    
    private func HourlyWeatherCell(hour: String, image: Image, temp: String) -> some View {
        VStack(spacing: Constants.Dimensions.secondSpacing) {
            Text(hour)
            image
                .resizable()
                .scaledToFill()
                .frame(width: Constants.Dimensions.defaultWidth,
                       height: Constants.Dimensions.defaultHeight,
                       alignment: .center)
            Text("\(temp)°C")
        }
        .font(.system(size: Constants.Font.smallSize))
        .foregroundStyle(.white)
        .padding()
        .background(
            RoundedRectangle(cornerRadius: Constants.Dimensions.cornerRadius)
                .fill(
                    LinearGradient(
                        gradient: Gradient(colors: Constants.Colors.gradient),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        )
        .shadow(color: Color.white.opacity(0.1),
                radius: 2,
                x: -2,
                y: -2)
        .shadow(color: Color.black.opacity(0.2),
                radius: 2,
                x: 2,
                y: 2)
    }
}

struct HourlyWeatherView_Previews: PreviewProvider {
    static var previews: some View {
        HourlyView(weatherViewModel: WeatherViewModel())
    }
}

struct CurrentlyWeatherView: View {
    @StateObject var weatherViewModel: WeatherViewModel
    
    var body: some View {
        VStack(spacing: Constants.Dimensions.firstSpacing) {
            weatherViewModel.getWeatherIconFor(icon: weatherViewModel.weatherIcon)
                .resizable()
                .scaledToFill()
                .frame(width: (CGFloat(3)*(Constants.Dimensions.defaultWidth)),
                       height: (CGFloat(3)*(Constants.Dimensions.defaultHeight)),
                       alignment: .center)
            HStack(spacing: Constants.Dimensions.secondSpacing) {
                VStack(alignment: .center) {
                    Text("\(weatherViewModel.temperature)°C")
                        .font(.system(size: Constants.Font.largeSize))
                    Text(weatherViewModel.conditions.localizated())
                        .font(.system(size: Constants.Font.mediumSize))
                }
            }
            HStack {
                Spacer()
                WidgetView(image: Constants.Images.wind,
                           text: Constants.Strings.windSpeed.localizated(),
                           title: "\(weatherViewModel.windSpeed) m/s")
                Spacer()
                WidgetView(image: Constants.Images.humidity,
                           text: Constants.Strings.humidity.localizated(),
                           title: "\(weatherViewModel.humidity)")
                Spacer()
                WidgetView(image: Constants.Images.umbrella,
                           text: Constants.Strings.rainChances.localizated(),
                           title: "\(weatherViewModel.rainChances)")
                Spacer()
            }
        }
        .padding()
        .foregroundStyle(.white)
        .background(
            RoundedRectangle(cornerRadius: Constants.Dimensions.cornerRadius)
                .fill(
                    LinearGradient(
                        gradient: Gradient(colors: Constants.Colors.gradient),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        )
        .shadow(color: Color.white.opacity(0.1), radius: 2, x: -2, y: -2)
        .shadow(color: Color.black.opacity(0.2), radius: 2, x: 2, y: 2)
    }
    
    private func WidgetView (image: String,
                             text: String,
                             title: String) -> some View {
        VStack {
            Text(text)
            Image(image)
                .resizable()
                .scaledToFill()
                .frame(width: Constants.Dimensions.defaultWidth,
                       height: Constants.Dimensions.defaultHeight,
                       alignment: .center)
            Text(title)
        }
        .font(.system(size: Constants.Font.smallSize))
    }
}

struct CurrentlyWeatherView_Previews: PreviewProvider {
    static var previews: some View {
        CurrentlyWeatherView(weatherViewModel: WeatherViewModel())
    }
}
