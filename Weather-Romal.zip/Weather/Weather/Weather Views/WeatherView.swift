//  WeatherView.swift

import SwiftUI

struct WeatherView: View {
    @StateObject var weatherViewModel: WeatherViewModel
    
    var body: some View {
        VStack {
            CurrentlyWeatherView(weatherViewModel: weatherViewModel)
                .padding()
            HourlyView(weatherViewModel: weatherViewModel)
                .padding(.horizontal)
            DailyWeatherView(weatherViewModel: weatherViewModel)
                .padding(.horizontal)
        }
    }
}

struct FullWeatherView_Previews: PreviewProvider {
    static var previews: some View {
        WeatherView(weatherViewModel: WeatherViewModel())
    }
}
