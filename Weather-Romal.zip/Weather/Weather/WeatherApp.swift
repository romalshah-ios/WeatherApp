//
//  WeatherApp.swift
//  Weather
//
//  Created by Romal Shah on 9/16/24.
//

import SwiftUI

@main
struct WeatherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
